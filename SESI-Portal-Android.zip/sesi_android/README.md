# SESI Portal do Aluno — Android

Versão Android do projeto para PC enviado.

### O que já está pronto
- Interface React/Vite existente colocada dentro do app Android.
- Aplicativo nativo com WebView e JavaScript habilitado.
- `localStorage`/DOM Storage habilitado para manter notas, faltas, médias e flashcards no aparelho.
- Ícone e nome configurados.
- Modo retrato para celular.
- Botão Voltar do Android funciona dentro do histórico do app.
- Links HTTP/HTTPS são enviados ao navegador externo.

### Abrir
Abra a pasta `sesi_android` no Android Studio e aguarde a sincronização do Gradle.
Depois conecte o celular ou abra um emulador e pressione **Run ▶**.

### APK
Use **Build > Build APK(s)**. O resultado será `app/build/outputs/apk/debug/app-debug.apk`.

### Nota sobre futuras alterações
O código web editável está em `web-source/`. A cópia compilada usada pelo Android está em `app/src/main/assets/`. Para atualizar o app depois de modificar React, rode `npm run build` no projeto web e copie o conteúdo de `dist/` para `app/src/main/assets/`.
