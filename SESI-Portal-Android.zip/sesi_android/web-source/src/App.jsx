import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  ChevronLeft, ChevronRight, Save, Calendar, Clock, CheckCircle2, 
  AlertCircle, Clock3, X, ListTodo, CheckCircle, Brain, 
  Calculator, LayoutDashboard, Plus, Trash2, FlipHorizontal,
  UserX, Info, History, ShieldCheck, ShieldAlert, TrendingUp
} from 'lucide-react';

// LocalStorage Storage System
const STORAGE_KEYS = {
  notes: 'sesi-portal-notes',
  absences: 'sesi-portal-absences',
  grades: 'sesi-portal-grades',
  flashcards: 'sesi-portal-flashcards',
};

const storageLib = {
  getNotes: () => JSON.parse(localStorage.getItem(STORAGE_KEYS.notes) || '{}'),
  setNotes: (data) => localStorage.setItem(STORAGE_KEYS.notes, JSON.stringify(data)),
  
  getAbsences: () => JSON.parse(localStorage.getItem(STORAGE_KEYS.absences) || '{}'),
  setAbsences: (data) => localStorage.setItem(STORAGE_KEYS.absences, JSON.stringify(data)),
  
  getGrades: () => JSON.parse(localStorage.getItem(STORAGE_KEYS.grades) || '{}'),
  setGrades: (data) => localStorage.setItem(STORAGE_KEYS.grades, JSON.stringify(data)),
  
  getFlashcards: () => JSON.parse(localStorage.getItem(STORAGE_KEYS.flashcards) || '[]'),
  setFlashcards: (data) => localStorage.setItem(STORAGE_KEYS.flashcards, JSON.stringify(data)),
  
  addFlashcard: (card) => {
    const cards = storageLib.getFlashcards();
    cards.push({ ...card, id: Date.now().toString() });
    storageLib.setFlashcards(cards);
    return cards;
  },
  
  deleteFlashcard: (id) => {
    const cards = storageLib.getFlashcards().filter(c => c.id !== id);
    storageLib.setFlashcards(cards);
    return cards;
  }
};

// --- CONFIGURAÇÕES DO CALENDÁRIO ---
const WEEKS_IN_YEAR = 38; 

const DAYS = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta'];
const DAYS_SHORT = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex'];
const TIMES = [
  '07:00 - 07:50', '07:50 - 08:40', '08:40 - 09:00', 
  '09:00 - 09:50', '09:50 - 10:40', '10:40 - 11:30', '11:30 - 12:20'
];

const SCHEDULE_DATA = {
  '07:00 - 07:50': ['EMP', 'QUI', 'FIS', 'IN', 'HI'],
  '07:50 - 08:40': ['BIO', 'QUI', 'FIS', 'IN', 'HI'],
  '08:40 - 09:00': ['INTERVALO', 'INTERVALO', 'INTERVALO', 'INTERVALO', 'INTERVALO'],
  '09:00 - 09:50': ['BIO', 'AR', 'EF', 'FIL', 'EMP'],
  '09:50 - 10:40': ['LP', 'AR', 'EF', 'FIL', 'SOC'],
  '10:40 - 11:30': ['MA', 'MA', 'GEO', 'LP', 'SOC'],
  '11:30 - 12:20': ['MA', 'MA', 'GEO', 'LP', 'TPT'],
};

const SUBJECT_CONFIG = {
  'BIO': { name: 'Biologia', color: 'bg-green-100 border-green-500 text-green-800' },
  'MA': { name: 'Matemática', color: 'bg-blue-100 border-blue-500 text-blue-800' },
  'FIS': { name: 'Física', color: 'bg-orange-100 border-orange-500 text-orange-800' },
  'QUI': { name: 'Química', color: 'bg-purple-100 border-purple-500 text-purple-800' },
  'LP': { name: 'Língua Portuguesa', color: 'bg-yellow-100 border-yellow-500 text-yellow-800' },
  'HI': { name: 'História', color: 'bg-red-100 border-red-500 text-red-800' },
  'GEO': { name: 'Geografia', color: 'bg-emerald-100 border-emerald-500 text-emerald-800' },
  'IN': { name: 'Inglês', color: 'bg-indigo-100 border-indigo-500 text-indigo-800' },
  'EMP': { name: 'Empreendedorismo', color: 'bg-pink-100 border-pink-500 text-pink-800' },
  'AR': { name: 'Artes', color: 'bg-violet-100 border-violet-500 text-violet-800' },
  'EF': { name: 'Educação Física', color: 'bg-lime-100 border-lime-500 text-lime-800' },
  'FIL': { name: 'Filosofia', color: 'bg-slate-100 border-slate-500 text-slate-800' },
  'SOC': { name: 'Sociologia', color: 'bg-stone-100 border-stone-500 text-stone-800' },
  'TPT': { name: 'Produção Textual', color: 'bg-cyan-100 border-cyan-500 text-cyan-800' },
};

const LESSONS_PER_WEEK = {};
Object.values(SCHEDULE_DATA).forEach(dayList => {
  dayList.forEach(sub => {
    if(sub !== 'INTERVALO') {
      LESSONS_PER_WEEK[sub] = (LESSONS_PER_WEEK[sub] || 0) + 1;
    }
  });
});

const STATUS_OPTIONS = [
  { id: 'pending', label: 'Pendente', icon: Clock3, color: 'bg-yellow-500' },
  { id: 'urgent', label: 'Urgente', icon: AlertCircle, color: 'bg-red-500' },
  { id: 'done', label: 'Concluído', icon: CheckCircle2, color: 'bg-green-500' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('schedule');
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const [notes, setNotes] = useState(storageLib.getNotes());
  const [absences, setAbsences] = useState(storageLib.getAbsences());
  const [grades, setGrades] = useState(storageLib.getGrades());
  const [flashcards, setFlashcards] = useState(storageLib.getFlashcards());
  
  const [editingCell, setEditingCell] = useState(null);
  const [showPendingList, setShowPendingList] = useState(false);
  const [showFlashcardModal, setShowFlashcardModal] = useState(false);
  
  const [tempText, setTempText] = useState('');
  const [tempStatus, setTempStatus] = useState('pending');
  const [newCard, setNewCard] = useState({ front: '', back: '', subject: 'MA' });

  const getMonday = useCallback((date) => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); 
    return new Date(d.getFullYear(), d.getMonth(), diff);
  }, []);

  const getWeekId = useCallback((date) => {
    const monday = getMonday(date);
    const year = monday.getFullYear();
    const startOfYear = new Date(year, 0, 1);
    const diffDays = Math.round((monday - startOfYear) / 86400000);
    const weekNo = Math.ceil((diffDays + 1) / 7);
    return `${year}-W${weekNo}`;
  }, [getMonday]);

  const saveNote = (cellIdOverride, textOverride, statusOverride) => {
    const targetId = cellIdOverride || editingCell;
    const updated = { ...notes };
    const text = textOverride ?? tempText;
    const status = statusOverride ?? tempStatus;
    if (!text.trim()) delete updated[targetId];
    else updated[targetId] = { text, status, updatedAt: Date.now() };
    storageLib.setNotes(updated);
    setNotes(updated);
    setEditingCell(null);
  };

  const updateAbsence = (sub, amount) => {
    const val = Math.max(0, (absences[sub] || 0) + amount);
    const updated = { ...absences, [sub]: val };
    storageLib.setAbsences(updated);
    setAbsences(updated);
  };

  const markDayAbsence = (dayIndex) => {
    const updatedAbsences = { ...absences };
    TIMES.forEach(time => {
      const sub = SCHEDULE_DATA[time][dayIndex];
      if (sub && sub !== 'INTERVALO') {
        updatedAbsences[sub] = (updatedAbsences[sub] || 0) + 1;
      }
    });
    storageLib.setAbsences(updatedAbsences);
    setAbsences(updatedAbsences);
  };

  const updateGrade = (sub, value) => {
    const val = parseFloat(value) || 0;
    const updated = { ...grades, [sub]: val };
    storageLib.setGrades(updated);
    setGrades(updated);
  };

  const addFlashcard = () => {
    if (!newCard.front || !newCard.back) return;
    const updated = storageLib.addFlashcard(newCard);
    setFlashcards(updated);
    setNewCard({ front: '', back: '', subject: 'MA' });
    setShowFlashcardModal(false);
  };

  const deleteFlashcard = (id) => {
    const updated = storageLib.deleteFlashcard(id);
    setFlashcards(updated);
  };

  const weekRange = useMemo(() => {
    const start = getMonday(currentDate);
    const end = new Date(start.getFullYear(), start.getMonth(), start.getDate() + 4);
    return { 
      text: `${start.toLocaleDateString('pt-BR', {day:'2-digit', month:'2-digit'})} - ${end.toLocaleDateString('pt-BR', {day:'2-digit', month:'2-digit'})}`, 
      start 
    };
  }, [currentDate, getMonday]);

  const pendingList = useMemo(() => {
    const list = [];
    Object.keys(notes).forEach(cellId => {
      const note = notes[cellId];
      if (note && note.status !== 'done' && note.text.trim() !== '') {
        const lastDashIdx = cellId.lastIndexOf('-');
        const time = cellId.substring(0, lastDashIdx);
        const dayIdx = parseInt(cellId.substring(lastDashIdx + 1));
        const subCode = SCHEDULE_DATA[time]?.[dayIdx] || 'Tarefa';
        const taskDate = new Date(weekRange.start.getFullYear(), weekRange.start.getMonth(), weekRange.start.getDate() + dayIdx);
        list.push({ id: cellId, timestamp: taskDate.getTime(), dateText: taskDate.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }), dayName: DAYS[dayIdx], text: note.text, status: note.status, subject: subCode });
      }
    });
    return list.sort((a, b) => a.timestamp - b.timestamp);
  }, [notes, weekRange.start]);

  const statsSummary = useMemo(() => {
    const subjects = Object.keys(SUBJECT_CONFIG);
    let totalAbsences = 0;
    let totalLessonsInYear = 0;
    let criticalCount = 0;
    
    const subjectStats = subjects.map(code => {
      const count = absences[code] || 0;
      const lessonsInYear = (LESSONS_PER_WEEK[code] || 0) * WEEKS_IN_YEAR;
      const freq = lessonsInYear > 0 ? ((lessonsInYear - count) / lessonsInYear) * 100 : 100;
      
      totalAbsences += count;
      totalLessonsInYear += lessonsInYear;
      
      if (freq <= 75) criticalCount++;
      return { code, freq, count, lessonsInYear };
    });

    const averageFreq = totalLessonsInYear > 0 ? ((totalLessonsInYear - totalAbsences) / totalLessonsInYear) * 100 : 100;
    return { averageFreq, criticalCount, subjectStats };
  }, [absences]);

  if (!notes) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 border-4 border-red-200 border-t-red-600 rounded-full animate-spin"></div>
        <p className="text-sm font-bold text-slate-400">CARREGANDO PORTAL...</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20 font-sans">
      
      {/* HEADER PRINCIPAL */}
      <header className="bg-red-700 text-white sticky top-0 z-40 shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white px-2 py-0.5 rounded font-black text-red-700 text-lg">SESI</div>
            <div className="hidden sm:block">
              <p className="text-[10px] opacity-70 uppercase font-bold tracking-tighter">Portal do Aluno</p>
              <h1 className="text-sm font-bold">1º B - Ensino Médio</h1>
            </div>
          </div>

          <nav className="flex bg-red-800 rounded-full p-1 text-[10px] font-bold shadow-inner">
            <button onClick={() => setActiveTab('schedule')} className={`px-3 sm:px-4 py-1.5 rounded-full transition-all ${activeTab === 'schedule' ? 'bg-white text-red-700 shadow-sm' : 'text-red-200 hover:text-white'}`}>HORÁRIO</button>
            <button onClick={() => setActiveTab('flashcards')} className={`px-3 sm:px-4 py-1.5 rounded-full transition-all ${activeTab === 'flashcards' ? 'bg-white text-red-700 shadow-sm' : 'text-red-200 hover:text-white'}`}>ESTUDO</button>
            <button onClick={() => setActiveTab('absences')} className={`px-3 sm:px-4 py-1.5 rounded-full transition-all ${activeTab === 'absences' ? 'bg-white text-red-700 shadow-sm' : 'text-red-200 hover:text-white'}`}>FALTAS</button>
            <button onClick={() => setActiveTab('grades')} className={`px-3 sm:px-4 py-1.5 rounded-full transition-all ${activeTab === 'grades' ? 'bg-white text-red-700 shadow-sm' : 'text-red-200 hover:text-white'}`}>NOTAS</button>
          </nav>

          <button onClick={() => setShowPendingList(true)} className="bg-white/20 hover:bg-white/30 px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 transition-all active:scale-95">
            <ListTodo size={14} />
            <span className="tabular-nums">{pendingList.length}</span>
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4">
        
        {/* TAB: HORÁRIO */}
        {activeTab === 'schedule' && (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div className="flex items-center justify-between bg-white p-3 rounded-2xl shadow-sm border border-slate-200">
               <button onClick={() => {const d=new Date(currentDate); d.setDate(d.getDate()-7); setCurrentDate(d);}} className="p-2 hover:bg-slate-100 rounded-full transition"><ChevronLeft /></button>
               <div className="text-center">
                 <span className="font-black text-xs sm:text-sm text-slate-600 uppercase tracking-widest">{weekRange.text}</span>
               </div>
               <button onClick={() => {const d=new Date(currentDate); d.setDate(d.getDate()+7); setCurrentDate(d);}} className="p-2 hover:bg-slate-100 rounded-full transition"><ChevronRight /></button>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead className="bg-slate-800 text-white">
                    <tr>
                      <th className="p-3 text-[10px] w-20">HORA</th>
                      {DAYS_SHORT.map((d, i) => {
                        const dObj = new Date(weekRange.start.getFullYear(), weekRange.start.getMonth(), weekRange.start.getDate() + i);
                        return (
                          <th key={d} className="p-3 text-center border-l border-slate-700">
                            <span className="block text-[10px] uppercase font-black">{d}</span>
                            <span className="block text-[8px] opacity-50 font-bold">{dObj.toLocaleDateString('pt-BR', {day:'2-digit', month:'2-digit'})}</span>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>
                  <tbody>
                    {TIMES.map(time => {
                      const isInterval = time === '08:40 - 09:00';
                      return (
                        <tr key={time} className={isInterval ? "bg-slate-50" : ""}>
                          <td className="p-2 border-b text-[9px] font-bold text-slate-400 text-center">{time}</td>
                          {isInterval ? <td colSpan={5} className="text-center text-[10px] font-black text-slate-200 tracking-[1.5em] py-4 bg-slate-50/50 uppercase">Intervalo</td> : 
                            DAYS_SHORT.map((_, i) => {
                              const code = SCHEDULE_DATA[time][i];
                              const cfg = SUBJECT_CONFIG[code];
                              const cellId = `${time}-${i}`;
                              const note = notes[cellId];
                              const isDone = note?.status === 'done';
                              
                              const count = absences[code] || 0;
                              const lessonsInYear = (LESSONS_PER_WEEK[code] || 0) * WEEKS_IN_YEAR;
                              const currentFreq = lessonsInYear > 0 ? ((lessonsInYear - count) / lessonsInYear) * 100 : 100;
                              const isAtRisk = currentFreq <= 75;

                              return (
                                <td key={cellId} onClick={() => {setEditingCell(cellId); setTempText(note?.text || ''); setTempStatus(note?.status || 'pending');}} className="p-1 border-b border-l border-slate-100 h-28 min-w-[120px] cursor-pointer hover:bg-slate-50 transition-colors">
                                  <div className={`h-full w-full rounded-xl border-l-4 p-2 flex flex-col transition-all relative overflow-hidden ${isDone ? 'bg-slate-100 border-slate-400 opacity-60' : (cfg?.color || 'bg-gray-100 border-gray-400 shadow-sm')} ${isAtRisk && !isDone ? 'ring-2 ring-red-500 ring-inset' : ''}`}>
                                    <div className="flex justify-between items-start mb-1 z-10">
                                      <span className={`text-[10px] font-black ${isDone ? 'line-through' : ''}`}>{code}</span>
                                      <div className="flex gap-1">
                                        {isAtRisk && !isDone && <AlertCircle size={10} className="text-red-600 animate-pulse" />}
                                        {note && <div className={`w-1.5 h-1.5 rounded-full ${STATUS_OPTIONS.find(s=>s.id===note.status)?.color || 'bg-slate-400'}`} />}
                                      </div>
                                    </div>
                                    <p className={`text-[9px] leading-tight line-clamp-3 font-bold mt-1 ${isDone ? 'line-through text-slate-400' : 'text-slate-700'}`}>{note?.text}</p>
                                    
                                    {!isDone && isAtRisk && (
                                      <div className="mt-auto pt-1 border-t border-red-200/50 flex items-center justify-between">
                                        <span className="text-[7px] font-black text-red-600 uppercase">Risco!</span>
                                        <span className="text-[7px] font-black text-red-500">{currentFreq.toFixed(0)}%</span>
                                      </div>
                                    )}
                                  </div>
                                </td>
                              );
                            })
                          }
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB: FALTAS */}
        {activeTab === 'absences' && (
          <div className="space-y-6 animate-in zoom-in-95 duration-300">
             
             {/* PAINEL DE RESUMO GERAL */}
             <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-6">
                   <div className="relative w-28 h-28 flex items-center justify-center">
                      <svg className="w-full h-full -rotate-90">
                        <circle cx="56" cy="56" r="50" fill="none" stroke="#f1f5f9" strokeWidth="8" />
                        <circle 
                          cx="56" cy="56" r="50" fill="none" stroke={statsSummary.averageFreq <= 75 ? "#ef4444" : "#10b981"} 
                          strokeWidth="8" strokeDasharray={314} 
                          strokeDashoffset={314 - (314 * statsSummary.averageFreq) / 100} 
                          strokeLinecap="round" className="transition-all duration-1000"
                        />
                      </svg>
                      <div className="absolute flex flex-col items-center">
                        <span className="text-2xl font-black text-slate-800 tracking-tighter">{statsSummary.averageFreq.toFixed(1)}%</span>
                        <span className="text-[8px] font-bold text-slate-400 uppercase">MÉDIA ANUAL</span>
                      </div>
                   </div>
                   <div className="flex-1 space-y-2 text-center sm:text-left">
                      <div className="flex items-center gap-2 justify-center sm:justify-start">
                         <h2 className="text-xl font-black text-slate-800 tracking-tight">Frequência Letiva</h2>
                         <TrendingUp size={16} className="text-slate-300" />
                      </div>
                      <div className="flex flex-wrap justify-center sm:justify-start gap-2">
                         {statsSummary.averageFreq > 75 ? (
                            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-[10px] font-black flex items-center gap-1">
                               <ShieldCheck size={12}/> ACIMA DA META (75%)
                            </span>
                         ) : (
                            <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-[10px] font-black flex items-center gap-1">
                               <ShieldAlert size={12}/> REPROVAÇÃO POR FALTAS
                            </span>
                         )}
                         {statsSummary.criticalCount > 0 && (
                            <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-[10px] font-black">
                               {statsSummary.criticalCount} DISCIPLINAS EM RISCO
                            </span>
                         )}
                      </div>
                      <p className="text-xs text-slate-500 font-medium">Cálculo baseado no calendário SESI (21/01 a 19/12) com aproximadamente 200 dias letivos.</p>
                   </div>
                </div>

                <div className="bg-slate-800 p-6 rounded-[32px] text-white flex flex-col justify-center items-center text-center shadow-lg relative overflow-hidden">
                   <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/5 rounded-full" />
                   <Info size={32} className="text-blue-400 mb-2" />
                   <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Cota de Faltas</p>
                   <p className="text-xs font-bold leading-relaxed px-2">Você pode faltar até 25% do ano. Mantenha o controle para não perder o ano letivo.</p>
                </div>
             </div>

             {/* MARCAR POR DIA */}
             <div className="space-y-3">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Faltou o dia inteiro?</h3>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                   {DAYS.map((day, i) => {
                     const dObj = new Date(weekRange.start.getFullYear(), weekRange.start.getMonth(), weekRange.start.getDate() + i);
                     return (
                       <button 
                         key={day} 
                         onClick={() => markDayAbsence(i)}
                         className="bg-white border-2 border-slate-100 hover:border-red-500 p-4 rounded-[28px] flex flex-col items-center gap-2 transition-all group active:scale-95 shadow-sm"
                       >
                         <UserX className="text-slate-300 group-hover:text-red-500 transition" size={24} />
                         <div className="text-center">
                           <span className="block text-[10px] font-black uppercase text-slate-400">{day}</span>
                           <span className="block text-xs font-bold text-slate-700">{dObj.toLocaleDateString('pt-BR', {day:'2-digit', month:'2-digit'})}</span>
                         </div>
                         <span className="text-[8px] font-black bg-red-50 text-red-600 px-2 py-0.5 rounded-full">+6 FALTAS</span>
                       </button>
                     )
                   })}
                </div>
             </div>

             {/* LISTA POR DISCIPLINA */}
             <div className="space-y-3">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Frequência por Disciplina</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   {statsSummary.subjectStats.map(({ code, freq, count, lessonsInYear }) => {
                     const isCritical = freq <= 75;
                     const isWarning = freq > 75 && freq <= 80;
                     const limitAbsences = Math.floor(lessonsInYear * 0.25);
                     
                     return (
                       <div key={code} className={`bg-white p-5 rounded-[32px] border shadow-sm flex flex-col gap-4 transition-all ${isCritical ? 'border-red-300 bg-red-50/20 shadow-red-100' : 'border-slate-100'}`}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                               <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xs shadow-inner ${SUBJECT_CONFIG[code].color}`}>
                                 {code}
                               </div>
                               <div>
                                 <p className="text-sm font-black text-slate-800">{SUBJECT_CONFIG[code].name}</p>
                                 <p className={`text-[10px] font-black uppercase ${isCritical ? 'text-red-600' : isWarning ? 'text-orange-500' : 'text-slate-400'}`}>
                                   {isCritical ? 'ALERTA DE REPROVAÇÃO' : isWarning ? 'LIMITE PRÓXIMO' : 'FREQUÊNCIA OK'}
                                 </p>
                               </div>
                            </div>
                            <div className="text-right">
                               <p className={`text-2xl font-black ${isCritical ? 'text-red-600' : 'text-slate-800'}`}>{freq.toFixed(0)}%</p>
                               <p className="text-[8px] font-bold text-slate-400 uppercase">PRESENÇA</p>
                            </div>
                          </div>

                          <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                             <div 
                               className={`h-full transition-all duration-1000 ${isCritical ? 'bg-red-500' : isWarning ? 'bg-orange-400' : 'bg-green-500'}`}
                               style={{ width: `${freq}%` }}
                             />
                          </div>

                          <div className="flex items-center justify-between pt-1">
                             <div className="flex flex-col">
                                <span className="text-[10px] font-black text-slate-700 uppercase">Faltas: {count} / {limitAbsences}</span>
                                <span className="text-[8px] font-bold text-slate-400 uppercase">Limite anual permitido</span>
                             </div>
                             <div className="flex items-center gap-2 bg-white p-1 rounded-xl shadow-sm border border-slate-100">
                                <button onClick={() => updateAbsence(code, -1)} className="w-8 h-8 flex items-center justify-center text-slate-400 hover:bg-slate-50 rounded-lg font-bold transition">-</button>
                                <span className="w-4 text-center font-black text-xs">{count}</span>
                                <button onClick={() => updateAbsence(code, 1)} className="w-8 h-8 flex items-center justify-center text-red-600 hover:bg-red-50 rounded-lg font-bold transition">+</button>
                             </div>
                          </div>
                       </div>
                     )
                   })}
                </div>
             </div>
          </div>
        )}

        {/* TAB: FLASHCARDS */}
        {activeTab === 'flashcards' && (
          <div className="space-y-6 animate-in slide-in-from-right duration-300">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight">Flashcards</h2>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Estudo Dinâmico</p>
              </div>
              <button onClick={() => setShowFlashcardModal(true)} className="bg-red-700 text-white px-5 py-2.5 rounded-2xl font-bold flex items-center gap-2 shadow-lg hover:bg-red-800 transition-all active:scale-95">
                <Plus size={20} /> Novo Card
              </button>
            </div>

            {flashcards.length === 0 ? (
              <div className="text-center py-24 bg-white rounded-[40px] border-2 border-dashed border-slate-200">
                <Brain size={64} className="mx-auto text-slate-100 mb-6" />
                <p className="text-slate-400 font-bold max-w-xs mx-auto text-sm italic">Crie cartões de estudo para memorizar conteúdos das aulas!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {flashcards.map(card => (
                  <Flashcard key={card.id} card={card} onDelete={() => deleteFlashcard(card.id)} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB: NOTAS */}
        {activeTab === 'grades' && (
          <div className="max-w-2xl mx-auto space-y-6 animate-in slide-in-from-bottom duration-300">
            <div className="text-center">
              <h2 className="text-2xl font-black text-slate-800 italic uppercase">Minhas Médias</h2>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-[0.2em] mt-1">Meta SESI: 7.0</p>
            </div>

            <div className="bg-white rounded-[32px] shadow-sm border border-slate-200 divide-y divide-slate-50 overflow-hidden">
              {Object.keys(SUBJECT_CONFIG).map(code => {
                const grade = grades[code] || 0;
                const isPass = grade >= 7;
                return (
                  <div key={code} className="p-5 flex items-center justify-between group hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-5">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xs shadow-inner ${SUBJECT_CONFIG[code].color}`}>
                        {code}
                      </div>
                      <div>
                        <p className="text-sm font-black text-slate-700">{SUBJECT_CONFIG[code].name}</p>
                        <p className={`text-[9px] font-black uppercase tracking-wider ${isPass ? 'text-green-600' : 'text-red-500'}`}>
                          {isPass ? 'Média Atingida' : 'Abaixo da Média'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <input 
                        type="number" step="0.1" min="0" max="10"
                        value={grade}
                        onChange={(e) => updateGrade(code, e.target.value)}
                        className={`w-20 p-3 rounded-2xl text-center font-black text-xl border-2 transition-all outline-none ${isPass ? 'border-green-100 bg-green-50 text-green-700 focus:border-green-500' : 'border-red-100 bg-red-50 text-red-700 focus:border-red-500'}`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      {/* MODAL: EDITAR AULA */}
      {editingCell && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95">
            <div className="p-6 border-b flex justify-between items-center bg-slate-50">
              <h3 className="font-black text-slate-700 italic">Conteúdo da Aula</h3>
              <button onClick={() => setEditingCell(null)} className="p-2 bg-white rounded-full shadow-sm hover:bg-slate-100 transition"><X size={20}/></button>
            </div>
            <div className="p-6 space-y-4">
              <textarea 
                value={tempText} 
                onChange={e=>setTempText(e.target.value)} 
                className="w-full h-36 p-5 bg-slate-50 rounded-2xl outline-none focus:ring-2 ring-red-500 font-bold text-slate-600 placeholder:text-slate-300 border-none shadow-inner" 
                placeholder="Anotações importantes..." 
              />
              <div className="flex gap-2">
                {STATUS_OPTIONS.map(opt => (
                  <button key={opt.id} onClick={()=>setTempStatus(opt.id)} className={`flex-1 py-3.5 rounded-2xl border-2 flex flex-col items-center gap-1 transition-all ${tempStatus === opt.id ? 'bg-slate-800 text-white border-slate-800 shadow-lg translate-y-[-2px]' : 'border-slate-100 text-slate-300 hover:border-slate-200'}`}>
                    <opt.icon size={18} /><span className="text-[9px] font-black uppercase">{opt.label}</span>
                  </button>
                ))}
              </div>
              
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Faltou nesta aula?</span>
                {(() => {
                  const lastDash = editingCell.lastIndexOf('-');
                  const time = editingCell.substring(0, lastDash);
                  const day = parseInt(editingCell.substring(lastDash + 1));
                  const sub = SCHEDULE_DATA[time][day];
                  if (!sub) return null;
                  return (
                    <div className="flex items-center gap-4 bg-slate-100 px-4 py-2 rounded-2xl">
                      <button onClick={()=>updateAbsence(sub, -1)} className="font-black text-slate-400">-</button>
                      <span className="font-black text-slate-700 min-w-[20px] text-center text-xs">{absences[sub] || 0}</span>
                      <button onClick={()=>updateAbsence(sub, 1)} className="font-black text-red-600">+</button>
                    </div>
                  );
                })()}
              </div>

              <button onClick={() => saveNote()} className="w-full bg-red-700 text-white py-4 rounded-2xl font-black shadow-lg hover:bg-red-800 transition-all active:scale-95 uppercase tracking-widest text-xs">Salvar Tudo</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: NOVO FLASHCARD */}
      {showFlashcardModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-[32px] overflow-hidden shadow-2xl">
            <div className="p-6 bg-slate-800 text-white flex justify-between items-center">
              <h3 className="font-black italic uppercase">Novo Flashcard</h3>
              <button onClick={() => setShowFlashcardModal(false)}><X/></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Matéria</label>
                <select value={newCard.subject} onChange={e=>setNewCard({...newCard, subject: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl mt-1 font-bold outline-none border-2 border-transparent focus:border-red-500 transition-all">
                  {Object.keys(SUBJECT_CONFIG).map(k => <option key={k} value={k}>{SUBJECT_CONFIG[k].name}</option>)}
                </select>
              </div>
              <textarea placeholder="Pergunta" value={newCard.front} onChange={e=>setNewCard({...newCard, front: e.target.value})} className="w-full p-5 bg-slate-50 rounded-2xl h-24 font-bold text-sm outline-none border-2 border-transparent focus:border-red-500 transition-all shadow-inner" />
              <textarea placeholder="Resposta" value={newCard.back} onChange={e=>setNewCard({...newCard, back: e.target.value})} className="w-full p-5 bg-slate-50 rounded-2xl h-24 font-bold text-sm border-2 border-transparent focus:border-green-500 transition-all outline-none shadow-inner" />
              <button onClick={addFlashcard} className="w-full bg-slate-800 text-white py-4 rounded-2xl font-black shadow-lg hover:bg-slate-900 transition active:scale-95 uppercase text-xs tracking-widest">Adicionar</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: PENDENTES */}
      {showPendingList && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-[40px] shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200">
            <div className="p-6 bg-slate-800 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <ListTodo size={24} className="text-red-400" />
                <div>
                  <h2 className="text-xl font-black italic uppercase tracking-tight">Tarefas da Semana</h2>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest font-black opacity-60">Organização</p>
                </div>
              </div>
              <button onClick={() => setShowPendingList(false)} className="p-2 hover:bg-white/10 rounded-full transition"><X size={24} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50">
              {pendingList.length === 0 ? (
                <div className="py-20 text-center space-y-4">
                  <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-inner"><CheckCircle2 size={32} /></div>
                  <p className="font-black text-slate-400 text-sm uppercase">Tudo em dia!</p>
                </div>
              ) : (
                pendingList.map((task) => (
                  <div key={task.id} className="bg-white border border-slate-100 rounded-3xl p-5 flex items-center justify-between group hover:shadow-md transition-all">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-black bg-slate-100 text-slate-500 px-2 py-0.5 rounded-lg uppercase tracking-tighter">{task.subject}</span>
                        <span className="text-[10px] font-black text-red-600 uppercase tracking-widest">{task.dateText}</span>
                      </div>
                      <p className="text-sm font-black text-slate-700">{task.text}</p>
                    </div>
                    <button onClick={() => saveNote(task.id, task.text, 'done')} className="ml-4 p-3 bg-slate-50 text-slate-300 hover:text-green-600 hover:bg-green-50 rounded-2xl transition-all active:scale-90"><CheckCircle size={32} /></button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

// --- SUB-COMPONENTE: FLASHCARD ---
function Flashcard({ card, onDelete }) {
  const [flipped, setFlipped] = useState(false);
  const cfg = SUBJECT_CONFIG[card.subject];
  return (
    <div className="h-64 relative [perspective:1000px] group">
      <div onClick={() => setFlipped(!flipped)} className={`relative w-full h-full transition-all duration-700 [transform-style:preserve-3d] cursor-pointer ${flipped ? '[transform:rotateY(180deg)]' : ''}`}>
        <div className="absolute inset-0 [backface-visibility:hidden] bg-white rounded-[32px] border-2 border-slate-100 p-8 flex flex-col justify-between shadow-sm group-hover:shadow-xl transition-all">
          <div className="flex justify-between items-start">
             <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase shadow-sm ${cfg?.color}`}>{card.subject}</span>
             <button onClick={(e) => { e.stopPropagation(); onDelete(); }} className="text-slate-200 hover:text-red-500 transition-colors p-1"><Trash2 size={16}/></button>
          </div>
          <div className="text-center font-black text-slate-800 text-xl leading-snug">{card.front}</div>
          <div className="flex items-center justify-center gap-2 text-[9px] font-black text-slate-300 uppercase tracking-widest"><FlipHorizontal size={12}/> Virar</div>
        </div>
        <div className="absolute inset-0 [backface-visibility:hidden] bg-slate-800 text-white rounded-[32px] p-8 flex flex-col items-center justify-center text-center [transform:rotateY(180deg)] shadow-2xl border-4 border-slate-700">
           <div className="absolute top-6 text-[9px] font-black text-slate-500 uppercase tracking-[0.3em]">Resposta</div>
           <p className="font-bold text-lg leading-relaxed">{card.back}</p>
        </div>
      </div>
    </div>
  );
}
